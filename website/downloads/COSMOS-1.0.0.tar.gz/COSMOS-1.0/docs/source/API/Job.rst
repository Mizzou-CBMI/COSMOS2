JobManager
==========

.. automodule:: cosmos.Job.models
   :members: JobAttempt