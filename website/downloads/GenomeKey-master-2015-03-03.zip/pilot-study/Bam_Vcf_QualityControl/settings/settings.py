
setting = {
           'gatk' : '/home/ettore/Scrivania/Software/GATK/GenomeAnalysisTK-3.1-1/GenomeAnalysisTK.jar',
           'reference': '/home/ettore/Scrivania/Genomes/Human_g1k_v37Chr/human_g1k_v37.fasta',
           'fastqc': '/home/ettore/Scrivania/Software/FastQC/fastqc',
           'vcf_concat': '/home/ettore/Scrivania/Software/vcftools_0.1.12/perl/vcf-concat',
           'vcf_sort': '/home/ettore/Scrivania/Software/vcftools_0.1.12/perl/vcf-sort',
           'vcf_toots': '/usr/local/bin/vcftools'
}
